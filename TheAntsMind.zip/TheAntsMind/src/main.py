import os
from dotenv import load_dotenv

load_dotenv()

print("Hola desde HormigasAIS!")
api_key = os.getenv("OPENAI_API_KEY")
print("Tu clave OpenAI es:", api_key if api_key else "No encontrada")
