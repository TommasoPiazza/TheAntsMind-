# TheAntsMind — HormigasAIS-ux

**TheAntsMind** es el nodo principal del laboratorio abierto de automatización, inteligencia artificial, SEO y scraping desarrollado por **HormigasAIS**. Este entorno está optimizado para integraciones inteligentes con GitHub Codespaces, n8n, y herramientas de desarrollo colaborativo.

## Estructura del Proyecto

- `.devcontainer/` — Configuración para entornos Codespaces.
- `src/` — Código fuente principal.
- `requirements.txt` — Dependencias en Python.
- `.env` — Variables de entorno locales (no se suben al repo).

## Cómo iniciar

```bash
git clone https://github.com/TheAntsMind/TheAntsMind.git
cd TheAntsMind
pip install -r requirements.txt
python src/main.py
```

---

## Mantenido por:
[Cristhiam Quiñonez](https://github.com/HormigasAIS-ux) | Fundador de HormigasAIS
